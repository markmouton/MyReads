import React, { Component } from 'react';
import * as BooksAPI from './BooksAPI';
import './App.css';

class BooksGrid extends Component {

constructor(props) {
super(props);
this.state = {
  data:[]
}
}
  
 componentWillMount() {
   this.getAll();
 }
  
async handleBookUpdate(book,event) {

    BooksAPI.update(book,event.target.value).then( await this.getAll());
}
   
async getAll(){
    await BooksAPI.getAll()
    .then(res =>  this.setState(...[{ data: JSON.stringify(res)}]));
}
   
shelfBuilder(shelfName) {
       var {data} =this.state;
       let  bookFilter=[];
         
     if(data && data.length > 0) {
         var jsonData = JSON.parse(data);
         bookFilter =  jsonData.filter(function (book) {
         return book.shelf === shelfName;
       });
    }
     
   return bookFilter.map((book) => {
    var imgLink = book.imageLinks.thumbnail;
    return (
      
       <li key={book.id}>
        <div className="book">
            <div className="book-top">
                <div className="book-cover" style={{ width: 128,height:193,backgroundImage:`url(${imgLink})`}}></div>
                
                <div className="book-shelf-changer">
                    <select onChange={(evt) => this.handleBookUpdate(book,evt)} defaultValue={'move'}  >
                        <option key="move"  value="move" disabled >Move to...</option> 
                        <option key="currentlyReading" value="currentlyReading">Currently Reading</option>
                        <option key="wantToRead" value="wantToRead">Want to Read</option>
                        <option key="read" value="read">Read</option>
                        <option key="none" value="none">None</option>
                    </select>
                </div>
            </div>
            <div className="book-title">{book.title}</div>
            <div className="book-authors">{book.authors[0]}</div>
        </div>
    </li>
  
    ) //ListEnd
   });
  
   }

 render(){
    return ( 
            <div className="list-books-content">
                <div className="bookshelf">
                  <h2 className="bookshelf-title">Currently Reading</h2>
                  <div className="bookshelf-books">
                 <ol className="books-grid">
                   {this.shelfBuilder("currentlyReading")}
                 </ol>
                  </div>
                </div>
                <div className="bookshelf">
                  <h2 className="bookshelf-title">Want to Read</h2>
                  <div className="bookshelf-books">
                  <ol className="books-grid">  
                     {this.shelfBuilder("wantToRead")}
                  </ol>
                  </div>
                </div>
                <div className="bookshelf">
                  <h2 className="bookshelf-title">Read</h2>
                  <div className="bookshelf-books">
                   <ol className="books-grid">  
                     {this.shelfBuilder("read")}
                   </ol>
                  </div>
                </div>
                 <div className="bookshelf">
                  <h2 className="bookshelf-title">None</h2>
                  <div className="bookshelf-books">
                   <ol className="books-grid">  
                     {this.shelfBuilder("none")}
                   </ol>
                  </div>
                </div>
                          
            <div className="open-search">
              <a onClick={() => this.setState({ showSearchPage: true })}>Add a book</a>
            </div>
          </div>
    
    );
}
}

export default BooksGrid;