import React, { Component } from 'react';
import MainComponent from './MainComponent';
import SearchBar from './SearchBar';
import './App.css'
import {Route} from  'react-router-dom';
import  {BrowserRouter} from "react-router-dom";

class BooksApp extends  Component {
  
 state = {
    data:[],
  }

render() {
   return (
    <BrowserRouter>
     <div className="app">
     
     <Route exact path="/">
     <MainComponent /> 
     </Route>
     
     <Route path="/search">
     <SearchBar /> 
     </Route>
     
     </div>
    </BrowserRouter>
  
);
}
}
export default BooksApp