import React, { Component } from 'react';
import BooksGrid from './BooksGrid';
import './App.css';
//import proptypes from 'prop-types'
import {Link} from "react-router-dom";

class MainComponent extends Component {

constructor(props) {
super(props);
this.state = {}
}
  
render(){
return (
      
<div className="list-books">
            <div className="list-books-title">
              <h1>MyReads</h1>
            </div>
           <BooksGrid />
            <div className="open-search">
              <Link to="/search">Add a book</Link>
</div>
</div>
          
);
}
}
export default MainComponent;